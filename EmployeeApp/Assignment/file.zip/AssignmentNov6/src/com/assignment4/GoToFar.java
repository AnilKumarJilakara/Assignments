package com.assignment4;

public class GoToFar {

	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5};
		
		try
		{
			for(int i=0;i<=arr.length;i++) {
				System.out.println(i + " :" + arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException a)
		{
			System.out.println("Now you've gone too far");
		}
		
	}

}
