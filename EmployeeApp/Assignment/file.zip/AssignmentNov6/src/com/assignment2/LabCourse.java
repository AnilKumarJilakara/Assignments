package com.assignment2;

public class LabCourse extends CollegeCourse {
	public LabCourse(int labfee) {
		super();

	}

	public LabCourse(String department, int courseNumber, int credits) {
		super(department, courseNumber, credits);
		this.fee += 50;
	}

	@Override
	public void display() {
		System.out.println("Lab Course Information:");
		super.display(); // Display parent class (CollegeCourse) information
	}
}
