package com.assignment2;

public class CollegeCourse {
	private String department;
    private int courseNumber;
    private int credits;
    protected int fee;
    
	public CollegeCourse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CollegeCourse(String department, int courseNumber, int credits) {
		super();
		this.department = department;
		this.courseNumber = courseNumber;
		this.credits = credits;
		this.fee = 120 * credits; // Calculating fee based on credits
	}
	
	
	
	 public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getCourseNumber() {
		return courseNumber;
	}

	public void setCourseNumber(int courseNumber) {
		this.courseNumber = courseNumber;
	}

	public int getCredits() {
		return credits;
	}

	public void setCredits(int credits) {
		this.credits = credits;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}
	
	
	

	public void display() {
	        System.out.println("Department: " + department);
	        System.out.println("Course Number: " + courseNumber);
	        System.out.println("Credits: " + credits);
	       System.out.println("Fee: $" + fee);
	    }
    
}
