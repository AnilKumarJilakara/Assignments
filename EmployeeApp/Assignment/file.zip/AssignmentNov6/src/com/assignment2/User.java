package com.assignment2;

import java.util.Scanner;

public class User {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
 
        System.out.println("Enter department (BIO, CHM, CIS, PHY, or any other): ");
        String department = scanner.next();
        System.out.println("Enter course number: ");
        int courseNumber = scanner.nextInt();
        System.out.println("Enter number of credits: ");
        int credits = scanner.nextInt();
 
       CollegeCourse course=new CollegeCourse();
        if (department.equals("BIO") || department.equals("CHM") || department.equals("CIS") || department.equals("PHY"))
        {
        	course = new LabCourse(department, courseNumber, credits);
        } else
        {
        	course = new CollegeCourse(department, courseNumber, credits);
        }
 
        course.display();
 
	}
}
