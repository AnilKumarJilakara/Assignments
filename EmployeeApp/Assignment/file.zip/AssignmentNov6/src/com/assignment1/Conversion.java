package com.assignment1;

public class Conversion {

	public static void main(String[] args) {
		String a="Anil";
		try {
			int n=Integer.parseInt(a);
			System.out.println(n);
	    }catch(NumberFormatException e) {
	    	System.out.println("String that does not represent an integer value");
	    }
	}

}
