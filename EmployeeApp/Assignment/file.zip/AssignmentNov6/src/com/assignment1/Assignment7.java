package com.assignment1;

import java.util.Scanner;

public class Assignment7 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		double num=sc.nextDouble();
		try {
				if(num>0) {
				double res=Math.sqrt(num);
				System.out.println("square root of "+ num+" is : "+res);
				}
				else {
					throw new ArithmeticException();
				}
		}catch(ArithmeticException e) {
			System.err.println("Number should not be negative");
		}
	}

}
