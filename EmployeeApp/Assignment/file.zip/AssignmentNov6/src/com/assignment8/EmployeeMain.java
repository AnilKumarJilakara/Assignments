package com.assignment8;

public class EmployeeMain {

	public static void main(String[] args) {
		
		try {
			Employee e1=new Employee(15,5);
			System.out.println("id :"+e1.getIdNum()+" Hourly Rate : "+e1.getHourlyWages());
		}catch(EmployeeException e) {
			System.out.println("Invalid hourly wages");
		}
		try {
			Employee e2=new Employee(14,75);
			System.out.println("id :"+e2.getIdNum()+" Hourly Rate : "+e2.getHourlyWages());
		}catch(EmployeeException e) {
			System.out.println("Invalid hourly wages");
		}
		try {
			Employee e3=new Employee(13,35);
			System.out.println("id :"+e3.getIdNum()+" Hourly Rate : "+e3.getHourlyWages());
		}catch(EmployeeException e) {
			System.out.println("Invalid hourly wages");
		}
	}

}
