package com.assignment8;

public class EmployeeException extends Exception {
	
	
	public EmployeeException(String msg) {
		super(msg);
	}

}
