package com.assignment8;

public class Employee {
	int idNum;
	int hourlyWages;
	public Employee(int idNum, int hourlyWages)throws EmployeeException {
		if(hourlyWages<6 || hourlyWages>50) {
			throw new EmployeeException("Invalis hourly wages "+hourlyWages);
		}
		else {
			this.hourlyWages=hourlyWages;
		}
		this.idNum = idNum;
		
		
	}
	public int getIdNum() {
		return idNum;
	}
	public int getHourlyWages() {
		return hourlyWages;
	}
	
	
}
