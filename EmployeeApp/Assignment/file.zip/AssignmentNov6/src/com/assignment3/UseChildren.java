package com.assignment3;

public class UseChildren {

	public static void main(String[] args) {
		Child m=new Male("Anil");
		Child fm=new Female("Anitha");
		m.display();
		fm.display();
	}

}
