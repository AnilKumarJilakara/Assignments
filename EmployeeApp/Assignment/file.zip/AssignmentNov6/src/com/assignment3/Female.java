package com.assignment3;

import java.util.Scanner;

public class Female extends Child {

	public Female(String name) {
		super(name, "Female");
		allocateAge();
	}

	
	@Override
	public void display() {
		System.out.println("name "+name);
		System.out.println("Gender "+gender);
		System.out.println("age  "+age);
	}

	@Override
	public void setAge(int age) {
		this.age=age;
	}
	public void allocateAge() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age :");
		int age=sc.nextInt();
		setAge(age);
	}

}
