package com.assignment3;

public abstract class Child {
	String name;
	String gender;
	int age;
	public Child(String name, String gender) {
		super();
		this.name = name;
		this.gender = gender;
	}
	public abstract void setAge(int age);
	public abstract void display();
	
	
}
