package com.assignment;

public class Main1 {

	public static void main(String[] args) {
		CEO c=new CEO("CEO","Take care of company");
		Manager m=new Manager("Manager","Manages the work");
		System.out.println("CEO Responsibility is : "+c.getResponsibility());
		System.out.println("CEO Role is  : "+c.getRoleName());
		System.out.println("Manager Responsibility is : "+m.getResponsibility());
		System.out.println("Manager Role  is : "+m.getRoleName());
		
	}

}
