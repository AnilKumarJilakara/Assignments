package com.assignment;

public interface Role {
	public String getRoleName();
	public String getResponsibility();
}
