package com.assignment;

public class CEO implements Role {
	String roleName;
	String responsibility;
	public CEO(String roleName, String responsibility) {
		super();
		this.roleName = roleName;
		this.responsibility = responsibility;
	}
	@Override
	public String getRoleName() {
		return roleName;
	}
	@Override
	public String getResponsibility() {
		return responsibility;
	}
	
	

}
