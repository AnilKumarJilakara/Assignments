package com.assignment;

public class Manager implements Role {
	String roleName;
	String responsibility;
	
	public Manager(String roleName, String responsibility) {
		super();
		this.roleName = roleName;
		this.responsibility = responsibility;
	}

	@Override
	public String getRoleName() {
		return roleName;
	}

	@Override
	public String getResponsibility() {
		return responsibility;
	}

}
