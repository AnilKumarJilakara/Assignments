package com.assignment6;

public class NegativeArraySizeException extends Exception {
	public NegativeArraySizeException() {
		super();
	}
}
