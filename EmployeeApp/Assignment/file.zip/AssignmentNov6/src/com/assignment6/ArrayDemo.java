package com.assignment6;

import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array : ");
	
		try {
			
			int n1=Integer.parseInt(sc.nextLine());
			if(n1>0) {
				int[] arr=new int[n1];
				System.out.println("Array created successfully");
			}
			else {
				throw new NegativeArraySizeException();
			}

		}catch(NegativeArraySizeException e) {
			System.out.println("Number should be positive");
		}catch(NumberFormatException f) {
			System.out.println("Format should be number");
		}

	}

}
