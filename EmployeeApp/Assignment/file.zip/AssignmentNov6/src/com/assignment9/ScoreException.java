package com.assignment9;

public class ScoreException extends Exception{
	public ScoreException(String msg) {
		super(msg);
	}

}
