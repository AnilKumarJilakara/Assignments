package com.assignment9;

import java.util.Scanner;

public class Student {
	int[] sid= {1,2,3,4,5};
	int score;
	
	public int[] getSid() {
		return sid;
	}
	public int getScore() {
		return score;
	}
	public void allocateScore(int score)throws ScoreException {
		if(score>100) {
			throw new ScoreException("Invalid marks");
		}
		else {
			this.score=score;
			
		}
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the score1 : ");
		int score1=sc.nextInt();
		System.out.println("Enter the score2 : ");
		int score2=sc.nextInt();
		System.out.println("Enter the score3 : ");
		int score3=sc.nextInt();
		System.out.println("Enter the score4 : ");
		int score4=sc.nextInt();
		System.out.println("Enter the score5 : ");
		int score5=sc.nextInt();
		Student s=new Student();
		try {
			s.allocateScore(score1);
			System.out.println("score of id : "+s.getSid()[0]+" is "+s.getScore());
		} catch (ScoreException e) {
			e.printStackTrace();
		}
		try {
			s.allocateScore(score2);
			System.out.println("score of id : "+s.getSid()[1]+" is "+s.getScore());
		} catch (ScoreException e) {
			e.printStackTrace();
		}
		try {
			s.allocateScore(score3);
			System.out.println("score of id : "+s.getSid()[2]+" is "+s.getScore());
		} catch (ScoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			s.allocateScore(score4);
			System.out.println("score of id : "+s.getSid()[3]+" is "+s.getScore());
		} catch (ScoreException e) {
			e.printStackTrace();
		}
		try {
			s.allocateScore(score5);
			System.out.println("score of id : "+s.getSid()[4]+" is "+s.getScore());
		} catch (ScoreException e) {
			e.printStackTrace();
		}
	}

}
